# OSTF 3.5.0 Demo Songs

These 11 complete songs are the 3.4 demo set carried forward to root version `3.5.0` without inventing new note-state values. 3.5 defaults preserve their 3.4 musical meaning.

The demos do **not** fabricate release velocity, note mute, probability, velocity deviation or fixed-trigger annotations where the source did not contain that information.
