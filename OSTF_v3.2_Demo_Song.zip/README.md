# OSTF Player v1.0 — OSTF 3.2 demo library

11 standalone UTF-8 JSON OSTF files extracted from the actual OSTF Player v1.0 built-in presets. Each file has a `.ostf` extension, root `format: "OSTF"`, root `version: "3.2.0"`, and `ppq: 960`. No proprietary player-only container is necessary.

## Versions

**Player version:** v1.0 (Max for Live application release).  **OSTF document format:** 3.2.0 (independent format version).

The source RC4 contained nine OSTF 3.2 documents, one OSTF 3.1 document (Pop), and one OSTF 3.0 feature document. The two legacy documents were explicitly promoted to OSTF 3.2.0 without synthesizing new notes, drum kits, velocities, voicings or credits. To keep the legacy **Shifting Ground** example MIDI-exportable under the stricter 3.2 mapping rules, we explicitly curated four `custom` MIDI mappings using its existing source `midiNote` pitch values; this is **not** a GM1 identity claim, and no played events were altered. Its obsolete "3.0 Feature Demo" title was shortened.

## How to use

1. Unzip the demo pack and choose any individual `.ostf` file.
2. Open OSTF Player v1.0 in Ableton Live, and use **Open .ostf** in the Player window.
3. Use Song and Tracks views, the built-in preview or MIDI export, and Print Lead Sheet as needed.
4. Keep this ZIP to track the exact OSTF 3.2 sources before migrating to future OSTF versions.

These documents are full song timelines, not audio files or Ableton Live sets. Player-local synthesizer timbres and Max for Live UI state are not standardized OSTF 3.2 preset fields.

## Authorship / rights

The GitHub handle **yoh-nak** identifies the software developer / demonstration data editor, **not the composer, lyricist or arranger**. Unsupported composition, lyricist, arrangement, copyright-holder, and CC BY license claims were removed from the bundled documents. Musical authorship and any permissions for redistribution or derivative uses must be verified separately; inclusion here does not itself grant a music license. In a print dialog, credits remain editable for the actual rights holder.

## Data fidelity

For each demo, chords, time maps, song sections, melody, instrument-track clips and their note IDs/positions/durations/velocities, separate percussion Sound Slot identities, pronunciation/lyric alignment and other custom extension data were preserved. The full schema-version promotion was based on the published OSTF 3.2 migration guide. See MANIFEST.json for titles, source wire versions and SHA-256 checksums.

Specification reference: https://github.com/yoh-nak/Open-Song-Timeline-Format-3.2
