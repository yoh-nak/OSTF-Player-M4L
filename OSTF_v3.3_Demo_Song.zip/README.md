# OSTF Player 1.1 — OSTF 3.3 demonstration songs

This package contains 11 standalone `.ostf` files matching the bundled demos in OSTF Player v1.1.
Each file declares `"version": "3.3.0"`. For the first ten genre-specific examples,
`"song.genres"` contains a stable ID and a source-authored genre name.
The eleventh, Shifting Ground, is a feature demonstration with no asserted musical genre,
so `song.genres` is absent (unspecified, not forced to Pop).

Changes from the OSTF 3.2 set are limited to the root format version and the optional
song-level genre field. All notes, chord voicings, velocities, lyrics, metadata,
extensions, references, IDs and timing remain unchanged.

`genre.name` is open-ended OSTF song metadata, not an instrument preset or an instruction
to synthesize a genre. OSTF Player does not change sound engine presets based on genre tags.

Old 3.0–3.2 files remain readable by the new Player without silent upgrades.
The original OSTF 3.2 demo set can be retained separately for regression tests.
See MANIFEST.json for SHA-256 checksums, per-file titles and migration provenance.

OSTF 3.3 specification: https://github.com/yoh-nak/Open-Song-Timeline-Format-3.3
Player project: https://github.com/yoh-nak/OSTF-Player-M4L
